function hideCookieLayer() {
    var layer = document.getElementById('cookieLayer');
    layer.style.display = 'none';
}